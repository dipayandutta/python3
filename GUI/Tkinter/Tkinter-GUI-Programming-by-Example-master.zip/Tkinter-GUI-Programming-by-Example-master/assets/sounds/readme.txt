 ---

Casino sounds by Kenney Vleugels (www.kenney.nl)

You may use these graphics in personal and commercial projects.
Credit (www.kenney.nl) would be nice but is not mandatory.

 --

 https://opengameart.org/content/54-casino-sound-effects-cards-dice-chips
