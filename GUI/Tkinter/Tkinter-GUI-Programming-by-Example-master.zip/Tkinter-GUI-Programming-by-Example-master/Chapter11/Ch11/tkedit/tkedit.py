from texteditor import main

main()
