myvariable = ['important', 'list']

def do_a_thing():
    print('mymod is doing something')

def do_another_thing():
    print('mymod is doing something else, and myvariable is', myvariable)
